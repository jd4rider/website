def setupshape(x,y, obj):
    obj.setheading(0)
    obj.penup()
    obj.goto(x,y)
    obj.pendown()

def angledcorners(obj):
    obj.left(45)
    obj.forward(42.4264068712)
    obj.left(45)

def drawJ(x,y, obj):
    y=y+75
    setupshape(x,y, obj)
    obj.right(90)
    obj.forward(75)
    obj.left(90)
    obj.forward(100)
    obj.left(90)
    obj.forward(200)

def drawD(x,y, obj):
    setupshape(x,y, obj)
    obj.forward(70)
    angledcorners(obj)
    obj.forward(140)
    angledcorners(obj)
    obj.forward(70)
    obj.left(90)
    obj.forward(200)
    obj.left(90)

def drawF(x,y, obj):
    setupshape(x,y, obj)
    obj.setheading(90)
    obj.forward(100)
    obj.right(90)
    obj.forward(70)
    obj.penup()
    obj.goto(x,250)
    obj.setheading(90)
    obj.pendown()
    obj.forward(100)
    obj.right(90)
    obj.forward(100)

def drawStar(x,y, size, obj):
    setupshape(x,y, obj)
    obj.setheading(36)
    obj.begin_fill()
    for i in range(0,5):
        obj.forward(size)
        obj.left(144)
    obj.fillcolor('white')
    obj.end_fill()

#flag functions

def drawSixRow(x, y, obj):
    starposx = x
    for i in range(0, 6):
        drawStar(starposx, y, 20, obj)
        starposx+=50

def drawFourRow(x, y, obj):
    starposx = x + 25
    for i in range(0, 5):
        drawStar(starposx, y, 20, obj)
        starposx+=50

def drawSeaOfBlue(x, y, obj):
    setupshape(x,y, obj)
    obj.begin_fill()
    for i in range(0,2):
        obj.forward(300)
        obj.right(90)
        obj.forward(250)
        obj.right(90)
    obj.color('#3C3B6E')
    obj.end_fill()

def drawFlag(x,y, obj):
    drawStripes(x-20, y+30, obj)
    drawSeaOfBlue(x -20,y+30, obj)
    for i in range(0,9):
        if i % 2 == 0:
            drawSixRow(x,y,obj)
        else:
            drawFourRow(x,y,obj)
        y -= 25

        
def drawStripe(x,y,obj):
    setupshape(x,y,obj)
    for i in range(0,2):
        obj.forward(750)
        obj.right(90)
        obj.forward(35.71)
        obj.right(90)

def drawRedStripe(x,y, obj):
    obj.begin_fill()
    drawStripe(x,y,obj)
    obj.fillcolor('#B22234')
    obj.end_fill()

def drawStripes(x,y,obj):
    for i in range(0,13):
        if i % 2 == 0:
            drawRedStripe(x,y,obj)
        else:
            drawStripe(x,y,obj)
        y -= 35.71
    
        
