import random
from datetime import datetime


def finddifficultylevel(difficulty):
    if difficulty <= 5:
        return "Easy Mode"
    elif difficulty <= 10:
        return "Medium Difficulty Mode"
    elif difficulty <= 20:
        return "Hard Mode"
    else:
        return "Mega Monster Super Duper Triple Crazy Hard Mode"

def maingame(name):
    random.seed(datetime.now())
    
    corrincorr = []
    correct = 0
    
    difficulty = input("How many Questions would you like to answer? ")
    difficultyint = int(difficulty)
    print(name+", you have chosen to play the game in "+finddifficultylevel(difficultyint))
    favnum = input("What is your favorite number? ")
    favnumint = int(favnum)

    #main loop
    for i in range(0, difficultyint):
        num1 = random.randint(0, favnumint)
        num1str = str(num1)
        num2 = random.randint(0, favnumint)
        num2str = str(num2)
        if int(input("What is "+num1str+" + "+num2str+"? ")) == (num1+num2):
            print("Correct answer!")
            correct+=1
        else:
            print("Incorrect answer.")




    print(" ")
    print("Score for "+name)
    print("---------------------------------")
    print("You had "+str(correct)+" out of "+difficulty+" correct answers.")
    print("Your average is: "+str(int((float(correct)/float(difficultyint)) *100))+"%")
    if input("Would you like to play again (Y/N)? ").upper() == "Y":
        print(" ")
        maingame(name)
    else:
        return
