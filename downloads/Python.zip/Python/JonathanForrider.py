import functionslib

#variables
numtrys = 0

#input
name = input("What is your name? ")

functionslib.maingame(name)

print("Thanks for playing!")
    



    

    


      

