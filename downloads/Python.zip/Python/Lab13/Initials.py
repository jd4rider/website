import turtle
import initialsfunctions

jon = turtle.Turtle();

jon.speed(0)

starposx = -350
starposy = 110

initialsfunctions.drawJ(-325, 150, jon)

initialsfunctions.drawD(-200, 150, jon)

initialsfunctions.drawF(-75, 150, jon)

initialsfunctions.drawFlag(starposx, starposy, jon)
        

initialsfunctions.setupshape(370, -370, jon)
jon.write('-Old Glory', font=("Arial", 14, "bold"))
